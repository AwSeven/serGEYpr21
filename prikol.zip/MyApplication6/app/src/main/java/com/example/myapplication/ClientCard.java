package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ClientCard extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clientcard);
    }
    public void onclick123 (View v){
        Intent intent = new Intent(ClientCard.this, Stor_Page.class);
        startActivity(intent);
    }
}
