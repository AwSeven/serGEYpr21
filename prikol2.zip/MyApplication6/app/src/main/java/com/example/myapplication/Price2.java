package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Price2  {
    public void onClickPrice2 (View v){
        Intent intent = new Intent(v.getContext(), Download.class);
        //startActivity(intent);
    }
}
